//
//  Shopping_ListTests.swift
//  Shopping ListTests
//
//  Created by Geovane Silva Pereira on 2/9/16.
//  Copyright © 2016 Geovane Silva Pereira. All rights reserved.
//

import XCTest
@testable import Shopping_List

class Shopping_ListTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measureBlock {
            // Put the code you want to measure the time of here.
        }
    }
    
}
